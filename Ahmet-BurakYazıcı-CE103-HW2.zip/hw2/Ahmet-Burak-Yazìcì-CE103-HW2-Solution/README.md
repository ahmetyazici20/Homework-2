# CE103 HW-2 template without function body
